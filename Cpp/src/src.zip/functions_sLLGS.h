/*
 * functions_sLLGS.h
 *
 *  Created on: 24 de out de 2017
 *      Author: joaonizer
 */

#ifndef FUNCTIONS_SLLGS_H_
#define FUNCTIONS_SLLGS_H_

#include <eigen3/Eigen/Dense>
#include <stdio.h>
#include <stdlib.h>
#include <string>


// Function to Calculate the Effective Field //
Eigen::RowVector3d compute_Heff(
		Eigen::RowVector3d m,
		Eigen::RowVector3d h_app,
		double hkms,
		Eigen::Matrix3d Nd,
		Eigen::RowVector3d h_c,
		Eigen::RowVector3d h_th,
		Eigen::RowVector3d n);

// Function to calculate the variation of magnetization //
Eigen::RowVector3d dm(
		Eigen::RowVector3d m,
		Eigen::RowVector3d h_eff,
		Eigen::RowVector3d i_s,
		float alpha,
		float alpha_l);

// Range-Kuta Method for Solving s-LLGS
Eigen::RowVector3d rk4(
		Eigen::RowVector3d m,
		Eigen::RowVector3d h_eff,
		Eigen::RowVector3d i_s,
		double dt,
		float alpha,
		float alpha_l);

// Function to Calculate the Demagnetizing Tensor //
Eigen::Matrix3d compute_Demag(
		Eigen::RowVector4d px,
		Eigen::RowVector4d py,
		double th);


#endif /* FUNCTIONS_SLLGS_H_ */
