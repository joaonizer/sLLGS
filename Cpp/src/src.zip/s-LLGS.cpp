//============================================================================
// Name        : s-LLGS.cpp
// Author      : João Nizer
// Version     : 0.0
// Copyright   : Universidade Federal de Minas Gerais - NanoComp
// Description : Solving s-LLGS in C++, Ansi-style
// References  : 2016 - Ament et al. - Solving the stochastic Landau-Lifshitz-
//			   : Gilbert-Slonczewski equation for monodomain nanomagnets.
//============================================================================

#include <iostream>
#include <stdio.h>
#include <eigen3/Eigen/Dense>
#include <cmath>

#include "functions_sLLGS.h"
using namespace std;

//=========================== Constants ================================
double gama = 2.211E5; 			// Giromagnetic Ratio in 	[m/A.s]*
double q     = 1.60217662E-19; 	// Electron charge 			[C]
double mu0   = 4*atan(1)*4*1E-7;// [H/m] or 				[T.m/A]^
double kb    = 1.38064852E-23;	// Boltzman"s Constant 		[m2.kg/s2.K]
double hbar  = 1.0545718E-34;	// Norm. Planks Const. 		[J.s/rad]
double t2am  = 1/mu0;			// Convert Tesla [T] to A/m
double j2ev  = 1/q;				// Convert Joule to eV
//* <cmath> already have a fun. called gamma with 2 M"s
//^ Pi value was calculated using atan(1)*4
//======================================================================

int main()
{

	int step=2; 							// Time Steps
	int n_of_particles = 2 ; 				// Quantidade de particulas
	double simulation_time = 100E-9; 		// Simulation Time in [s]
	double time_step = simulation_time/step;// Time step in [s]
	double dt = 1.7688;						// Normalized Time_Step
	float alpha = 1; 						// Gilbert damping constant
	float alpha_l = 1/(1+pow(alpha,2));		// Scaling factor for LLGS
	float Ms = 8E5;							// Saturation Manetization [A/m]
	float T = 300;							// Tmperature in Kelvin [K]
	Eigen::RowVector3d n;					// Easy axis of particles
		n << 0,1,0;


	Eigen::RowVector3d m[step][n_of_particles]; // Particles magnetization
	m[0][0] << 0     ,   -1.0000,         0;
	m[0][1] << 0.000918489,   -0.999999995,   -0.000332222204;
	m[1][0] << 0     ,    1.0000,         0;
	m[1][1] << -0.00035298522,    0.9999995913,   -0.00083228704;

	Eigen::RowVector3d h_app[step][n_of_particles]; // External applied field
	h_app[0][0]<<0,0,0;
	h_app[0][1]<<0,0,0;
	h_app[1][0]<<0,0,0;
	h_app[1][1]<<0.002978625,0,0;

	Eigen::RowVector3d i_s[step][n_of_particles]; // Spin current
	i_s[0][0]<<0,0,0;
	i_s[0][1]<<0,0,0;
	i_s[1][0]<<0,0,0;
	i_s[1][1]<<0,0,0;

	double hkms = 0.0012;

	Eigen::Matrix3d Nd[n_of_particles]; // Demagnetizing Tensor
	Nd[0]<<     0.25868898  ,  0.000488528  , -0.00946524,
			   -0.003351034161  ,  0.12646063944  ,  0.0111477192,
			    0.00621052985  ,  0.000314903194  ,  0.617292623552;
	Nd[1]<< Nd[0];

	Eigen::Matrix3d Nc[n_of_particles][n_of_particles]; // Coupling Tensor

	Eigen::RowVector3d h_c[step][n_of_particles]; // Coupling field
	h_c[0][0]<<-0.000169339401525,    0.016926196462,   -0.0000334531;
	h_c[0][1]<<-0.0001488901994,    0.01692627716,   -0.000067733553505;
	h_c[1][0]<< 0.000162029846,   -0.016856965599,   -0.0000879955;
	h_c[1][1]<< 0.000108696142,   -0.0168571356146,  -0.00010170834;

	Eigen::RowVector3d h_th[step][n_of_particles]; // Thermal field
	Eigen::RowVector3d h_eff[step][n_of_particles]; // Effective field

	for (int i=0;i<step;i++){  					// Iterate over steps
		for (int j=0;j<n_of_particles;j++){ 	// Iterate over the particles in the step i
			for (int k=0;k<n_of_particles;k++){
				Nc[j][k]= Eigen::Matrix3d::Zero();
			}
			Nd[j]		= Eigen::Matrix3d::Zero();
			m[i][j] 	= Eigen::RowVector3d::Zero();//
			h_eff[i][j] = Eigen::RowVector3d::Zero();//
			h_app[i][j] = Eigen::RowVector3d::Zero();//
			i_s[i][j] 	= Eigen::RowVector3d::Zero();//
			h_c[i][j] 	= Eigen::RowVector3d::Zero();//
			h_th[i][j] 	= Eigen::RowVector3d::Zero();//
		}
	}

	h_th[0][1]<< 0.013580972,   -0.00215136393,   -0.0020920577;
	h_th[1][0]<<-0.000946930,   -0.00119791500,   -0.0064141451;
	h_th[1][1]<<-0.000274711,    0.00747271693,    0.0095584490;


// TODO: Calculate Demag Tensors //


	for (int j=0;j<n_of_particles;j++){

	}


// Core Algorithm for Solving the s-LLGS equation //

	cout << "------------------------------------" 			<< endl;
	cout << "            Range-Kutta             " 			<< endl;
	cout << "------------------------------------" 			<< endl;
	cout << "dt real: \t\t" 	<< time_step 		<< " s"	<< endl;
	cout << "dt linha: \t\t" 	<< dt 		 				<< endl;
	cout << "tempo_total:\t\t" 	<< simulation_time 	<< " s" << endl;
	cout << "N: \t\t\t" 		<< step 					<< endl;
	cout << "------------------------------------"			<< endl;

	for (int i=0;i<step;i++){  					// Iterate over steps
		for (int j=0;j<n_of_particles;j++){ 	// Iterate over the particles in the step i

			for (int k=0;k<n_of_particles;k++){ // Calculates Coupling for step i
				h_c[i][j] += m[i][k]*Nc[j][k];
			} // end iterate over coupling

			// Compute the effective Field for particle j at step i
			h_eff[i][j] = compute_Heff(m[i][j], h_app[i][j], hkms, Nd[i],  h_c[i][j],  h_th[i][j], n);
			// Compute the new value of m for the step i+1;
			m[i+1][j] = rk4(m[i][j], h_eff[i][j], i_s[i][j], dt,alpha,alpha_l);

		} // end iterate over particles
	} // end iterate over steps
// End of s-LLGS calculation
	Eigen::RowVector4d px;
	Eigen::RowVector4d py;
	float th;
	compute_Demag( px, py, th);

}
