/*
 * compute_Demag.cpp
 *
 *  Created on: 25 de out de 2017
 *      Author: joaonizer
 */

#include "functions_sLLGS.h"
#include <iostream>


std::string GetStdoutFromCommand(std::string cmd) {

	std::string data;
	FILE * stream;
	const int max_buffer = 256;
	char buffer[max_buffer];
	cmd.append(" 2>&1");

	stream = popen(cmd.c_str(), "r");
	if (stream) {
		while (!feof(stream))
			if (fgets(buffer, max_buffer, stream) != NULL) data.append(buffer);
		pclose(stream);
	}
	return data;
}

extern"C" {
void demag3D3(double *px, double *py, double *th, double *d);
}

Eigen::Matrix3d compute_Demag(Eigen::RowVector4d px, Eigen::RowVector4d py, double th){

	double ppx [4] = {px(0), px(1), px(2), px(3)};
	double ppy [4] = {py(0), py(1), py(2), py(3)};
	double pd [9] = { 0 };
	Eigen::Matrix3d ppd;

	demag3D3(ppx,ppy,&th,pd);
	ppd(0,0) = pd[0];
	ppd(0,1) = pd[1];
	ppd(0,2) = pd[2];
	ppd(1,0) = pd[3];
	ppd(1,1) = pd[4];
	ppd(1,2) = pd[5];
	ppd(2,0) = pd[6];
	ppd(2,1) = pd[7];
	ppd(2,2) = pd[8];

	return ppd;

}

